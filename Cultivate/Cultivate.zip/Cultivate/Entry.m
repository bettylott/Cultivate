//
//  Entry.m
//  Cultivate
//
//  Created by Lisa Matter on 2/21/15.
//  Copyright (c) 2015 MSSE 650. All rights reserved.
//

#import "Entry.h"


@implementation Entry

@dynamic type;
@dynamic hours;
@dynamic date;

@end
